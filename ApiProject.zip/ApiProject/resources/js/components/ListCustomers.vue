<template>
  <div>
    <center><h1>Customer List</h1></center>
    <form>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputName">Name</label>
      <input type="text" class="form-control" id="inputName" placeholder="Name">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPhone">Phone</label>
      <input type="text" class="form-control" id="inputPhone" placeholder="Phone">
    </div>
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail">Email</label>
      <input type="email" class="form-control" id="inputEmail" placeholder="Email">
    </div>
    <div class="form-group col-md-6">
      <label for="inputCity">City</label>
      <input type="text" class="form-control" id="inputCity" placeholder="City">
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Address</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
  </div>
  <button type="submit" class="btn btn-primary">Add new customer</button>

</form>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">NAME</th>
          <th scope="col">PHONE</th>
          <th scope="col">ADDRESS</th>
          <th scope="col">EMAIL</th>
          <th scope="col">CITY</th>
          <th scope="col">ACTION</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="customer in customers"  :key="customer.id">
          <th scope="row">{{customer.id}}</th>
          <td>{{customer.name_customer}}</td>
          <td>{{customer.phone_customer}}</td>
          <td>{{customer.address_customer}}</td>
          <td>{{customer.email_customer}}</td>
          <td>{{customer.city_customer}}</td>
          <td><button type="button" class="btn btn-primary" @click="deleteCustomer(customer.id)">Delete</button>
              <button type="button" class="btn btn-warning">Edit</button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

 <script>

 import axios from 'axios'
  export default{
    data () {
      return {
        customers:[]
      }
    },
    methods: {
      getCustomers: function () {
          axios
          .get('http://127.0.0.1:8000/api/customers')
          .then(response => (this.customers = response.data))
          .catch(error => console.log(error))
      },
      deleteCustomer: function (id) {
          axios
          .delete('http://127.0.0.1:8000/api/customers/'+id)
          this.getCustomers()
      },
    },

    mounted () {
      this.getCustomers()
    },

    created () {
      this.getCustomers()
    }
  }
 </script>
 <style>
 </style>
