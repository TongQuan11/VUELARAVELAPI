require('./bootstrap');
window.Vue = require('vue').default;

Vue.component('list-customers', require('./components/ListCustomers.vue').default);

const app = new Vue({
    el: '#app',
});
