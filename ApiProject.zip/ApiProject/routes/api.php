<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomerController;

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

// Route::get('/customers', [CustomerController::Class,'index']);
// Route::post('/customer', [CustomerController::Class,'store']);
// Route::get('/customers/{id}', [CustomerController::Class,'show']);
// Route::put('/customers/{id}', [CustomerController::Class,'update']);
// Route::delete('/customers/{id}', [CustomerController::Class,'destroy']);

Route::resource('/customers', 'App\Http\Controllers\CustomerController');

// Route::get('/customers', 'App\Http\Controllers\CustomerController@index');
// Route::post('/customer', 'App\Http\Controllers\CustomerController@store');
// Route::get('/customers/{id}', 'App\Http\Controllers\CustomerController@show');
// Route::put('/customers/{id}', 'App\Http\Controllers\CustomerController@update');
// Route::delete('/customers/{id}', 'App\Http\Controllers\CustomerController@destroy');
